Maximum sum contiguous subarray
--------------------------------
Computes maximum contiguous subarray using two approaches - Dynamic Programming and Divide and Conquer
--------------------------------
Running the program :

make clean
make
