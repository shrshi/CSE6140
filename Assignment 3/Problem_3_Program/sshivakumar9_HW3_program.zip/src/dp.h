void dp(double *arr, int n, double *max_sum, int *max_li, int *max_ri);
