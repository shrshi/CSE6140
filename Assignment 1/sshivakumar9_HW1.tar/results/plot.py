import matplotlib.pyplot as plt
import subprocess, os

x = []
y_static = []
y_dynamic = []
output = subprocess.check_output("./plot_helper.sh")

lines = output.splitlines()
print len(lines)
for num, line in enumerate(lines):
	if num<13:
		x.append(float(line))
del lines[0:13]

for f in range(13):
	s = 0.0
	for num, line in enumerate(lines):
		if num==0:
			y_static.append(float(lines[num]))
		elif num!=0 and num<1001:
			s = s + float(line)
		else:
			break
	y_dynamic.append(s)
	del lines[0:1001]
print x, y_static, y_dynamic
plt.figure(1)

plt.subplot(211)
plt.plot(x, y_static, 'b', label='Static computation')
plt.xlabel('Number of edges in graph')
plt.ylabel('Time taken (secs)')
plt.legend(loc='upper left')

plt.subplot(212)
plt.plot(x, y_dynamic, 'g', label='Dynamic computation')
plt.xlabel('Number of edges in graph')
plt.ylabel('Time taken (secs)')
plt.legend(loc='upper left')		
plt.show()
